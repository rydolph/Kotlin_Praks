class Expense{
    var amount: Double
    var kategory: String
    var date: String

    constructor(amount: Double, kategory: String, date: String) {
        this.amount = amount
        this.kategory = kategory
        this.date = date
    }

    fun showExpense() {
        println("Сумма: $amount, Категория: $kategory, Дата: $date")
    }

    fun  updateAmount(newAmount: Double){
        amount = newAmount
    }
}