class ExpenseTracker {
    private val expenses = mutableListOf<Expense>()

    fun addExpense(expense: Expense){
        expenses.add(expense)
    }

    fun printAll(){
        if (expenses.isEmpty()){
            println("Нет расходов")
            return
        }else{
            for (expense in expenses){
                expense.showExpense()
            }
        }
    }

    fun calculateAllExpensesByCategory(){
        if (expenses.isEmpty()){
            println("Нет расходов")
            return
        }else{

            val kategorySum = mutableMapOf<String, Double>()

            for(expense in expenses){
                kategorySum[expense.kategory] = kategorySum.getOrDefault(expense.kategory, 0.0) + expense.amount
            }

            for((kategory, amount) in kategorySum){
                println("Категория: $kategory, Сумма: $amount")
            }
        }
    }

}