fun main() {
    val exp_tracker = ExpenseTracker()

    exp_tracker.addExpense(Expense(1000.0, "Any", "12.12.2022"))
    exp_tracker.addExpense(Expense(200.0, "Any", "09.11.2022"))
    exp_tracker.addExpense(Expense(400.0, "Dress", "22.04.2022"))
    exp_tracker.addExpense(Expense(5200.0, "Dress", "12.12.2022"))

    exp_tracker.printAll()

    exp_tracker.calculateAllExpensesByCategory()

}
